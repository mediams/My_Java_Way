package transport;

public interface ElectricVehicle {
    int chargeBattery();


}
